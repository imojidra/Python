import random
import time

class CrystalBall:
    def __init__(self):
        self.responses = [
            "A great success is coming your way",
            "You will soon find true love",
            "A hidden talent will be revealed to you",
            "A new adventure is just around the corner",
            "You will receive an unexpected gift",
            "Your hard work will pay off soon",
            "A mysterious stranger will enter your life",
            "You will discover a new passion",
            "A long-lost friend will reconnect with you",
            "You will find a new sense of purpose"
        ]

    def ask_question(self, question):
        print(f"Question: {question}")
        print("Gazing into the crystal ball...")
        time.sleep(2)  # add a delay for dramatic effect
        print(f"The crystal ball reveals: {random.choice(self.responses)}")

    def get_fortune(self):
        print("Reading your fortune...")
        time.sleep(2)
        fortune = random.choice([
            "You will have a great day today",
            "You will meet someone special soon",
            "You will receive good news this week",
            "You will have a successful month",
            "You will find happiness and prosperity"
        ])
        print(f"Your fortune: {fortune}")

def main():
    crystal_ball = CrystalBall()
    while True:
        print("\nOptions:")
        print("1. Ask a question")
        print("2. Get your fortune")
        print("3. Quit")
        choice = input("Choose an option: ")
        if choice == "1":
            question = input("Ask a question: ")
            crystal_ball.ask_question(question)
        elif choice == "2":
            crystal_ball.get_fortune()
        elif choice == "3":
            break
        else:
            print("Invalid option. Please choose again.")

if __name__ == "__main__":
    main()